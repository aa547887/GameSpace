﻿namespace GamiPort.Services
{
	public static class ImagePathService
	{
		// 預設頭像的相對路徑
		public const string DefaultUserAvatar = "/images/預設人物.png";
	}
}
