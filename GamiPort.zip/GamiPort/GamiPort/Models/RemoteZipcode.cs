﻿using System;
using System.Collections.Generic;

namespace GamiPort.Models;

public partial class RemoteZipcode
{
    public string Zipcode { get; set; } = null!;
}
