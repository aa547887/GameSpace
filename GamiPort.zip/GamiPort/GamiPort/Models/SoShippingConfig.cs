﻿using System;
using System.Collections.Generic;

namespace GamiPort.Models;

public partial class SoShippingConfig
{
    public string CfgKey { get; set; } = null!;

    public decimal CfgValue { get; set; }
}
