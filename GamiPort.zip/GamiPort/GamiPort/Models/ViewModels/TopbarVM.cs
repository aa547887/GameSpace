﻿namespace GamiPort.Models.ViewModels
{
	public class TopbarVM
	{
		public bool IsAuthenticated { get; set; }
		public string? NickName { get; set; }
	}
}
