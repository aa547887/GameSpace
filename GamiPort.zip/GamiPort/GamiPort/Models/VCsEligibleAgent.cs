﻿using System;
using System.Collections.Generic;

namespace GamiPort.Models;

public partial class VCsEligibleAgent
{
    public int ManagerId { get; set; }
}
