﻿using System;
using System.Collections.Generic;

namespace GamiPort.Models;

public partial class SMerchType
{
    public int MerchTypeId { get; set; }

    public string MerchTypeName { get; set; } = null!;
}
