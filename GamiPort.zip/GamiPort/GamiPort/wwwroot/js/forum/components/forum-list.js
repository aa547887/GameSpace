﻿// 顯示所有論壇；點擊導到 /Forum/Threads?forumId=xxx
export const ForumList = {
  template: `
    <section>
      <div class="input-group mb-3">
        <input class="form-control" type="search" placeholder="搜尋論壇"
               v-model="keyword" @keyup.enter="searchNow" :disabled="loading">
        <button class="btn btn-primary" @click="searchNow" :disabled="loading">搜尋</button>
        <button class="btn btn-outline-secondary" @click="clearSearch" :disabled="loading || !keyword">清除</button>
      </div>

      <div v-if="error" class="alert alert-danger">{{ error }}</div>

      <ul v-if="!loading" class="list-group mb-3">
        <li v-for="f in items" :key="f.forumId || f.id" class="list-group-item d-flex justify-content-between">
          <a :href="'/Forum/Threads?forumId=' + (f.forumId ?? f.id)"
             class="link-underline link-underline-opacity-0">
            {{ f.name }}
          </a>
          <small class="text-muted">貼文 {{ f.threadsCount ?? 0 }}</small>
        </li>
        <li v-if="items.length===0" class="list-group-item text-muted">沒有符合的論壇</li>
      </ul>

      <div class="d-flex align-items-center gap-2">
        <button class="btn btn-outline-secondary" @click="prev" :disabled="loading || page<=1">上一頁</button>
        <span class="small text-muted">第 {{ page }} / {{ pages }} 頁（{{ total }} 筆）</span>
        <button class="btn btn-outline-secondary" @click="next" :disabled="loading || page>=pages">下一頁</button>
      </div>
    </section>
  `,
  data(){ return { keyword:'', page:1, pageSize:20, total:0, items:[], loading:false, error:'' }; },
  computed:{ pages(){ return Math.max(1, Math.ceil(this.total / this.pageSize)); } },
  methods:{
    async fetchForums(){
      this.loading = true; this.error = '';
      try{
        const q = new URLSearchParams({ keyword:this.keyword ?? '', page:String(this.page), pageSize:String(this.pageSize) });
        const res = await fetch(`/api/forums?${q.toString()}`, { headers:{ 'Accept':'application/json' }});
        if(!res.ok) throw new Error('API 失敗：/api/forums ' + res.status);
        const data = await res.json();
        this.items = data.items ?? [];
        this.total = data.total ?? this.items.length;
        this.page = data.page ?? this.page;
        this.pageSize = data.pageSize ?? this.pageSize;
      }catch(err){ this.error = err.message ?? String(err); }
      finally{ this.loading = false; }
    },
    searchNow(){ this.page = 1; this.fetchForums(); },
    clearSearch(){ this.keyword=''; this.page=1; this.fetchForums(); },
    next(){ if(this.page < this.pages){ this.page++; this.fetchForums(); } },
    prev(){ if(this.page > 1){ this.page--; this.fetchForums(); } }
  },
  mounted(){ this.fetchForums(); }
};
