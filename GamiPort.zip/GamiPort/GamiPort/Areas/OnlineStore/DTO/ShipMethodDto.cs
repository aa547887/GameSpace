﻿namespace GamiPort.Areas.OnlineStore.DTO
{
	public sealed class ShipMethodDto
	{
		public int ShipMethodId { get; set; }
		public string MethodName { get; set; } = "";
	}
}
