﻿namespace GamiPort.Areas.OnlineStore.DTO
{
	public sealed class PayMethodDto
	{
		public int PayMethodId { get; set; }
		public string MethodName { get; set; } = "";
	}
}
