﻿namespace GamiPort.Areas.Forum.Dtos.Forum
{
    public sealed record ForumListItemDto(
      int ForumId,
      int GameId,
      string Name,
      string? Description
  );
}
