﻿namespace GamiPort.Areas.Forum.Dtos.Threads
{
    public record LikeStatusDto(bool IsLiked, int LikeCount);
}
