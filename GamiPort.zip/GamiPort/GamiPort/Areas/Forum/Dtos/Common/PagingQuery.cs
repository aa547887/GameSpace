﻿namespace GamiPort.Areas.Forum.Dtos.Common
{

    public sealed record PagingQuery(int Page = 1, int Size = 20);
    //public class PagingQuery
    //{
    //}
}
