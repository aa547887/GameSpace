﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using System.Threading.Tasks;
using GameSpace.Models; // <-- ManagerDatum, GameSpacedatabaseContext
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GameSpace.Controllers
{
	public class LoginController : Controller
	{
		private readonly GameSpacedatabaseContext _db;

		// 鎖定/驗證相關參數（可依需求調整）
		private const int MaxFailedAccessCount = 5;       // 連續失敗 5 次
		private static readonly TimeSpan LockoutDuration = TimeSpan.FromMinutes(15);
		private const string OtpSessionUserIdKey = "ManagerOtpUserId";
		private const string OtpSessionCodeKey = "ManagerOtpCode";
		private const string OtpSessionExpireKey = "ManagerOtpExpire";

		public LoginController(GameSpacedatabaseContext db)
		{
			_db = db;
		}

		// GET: /Login
		[HttpGet]
		[AllowAnonymous]
		public IActionResult Index()
		{
			return View("Login", new LoginInput());
		}

		// POST: /Login
		[HttpPost]
		[AllowAnonymous]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Index(LoginInput input)
		{
			if (!ModelState.IsValid)
			{
				return View("Login", input);
			}

			var now = DateTime.UtcNow;
			var account = input.ManagerAccount?.Trim();
			var pwd = input.ManagerPassword?.Trim();

			var manager = await _db.ManagerData
				.FirstOrDefaultAsync(m => m.ManagerAccount == account);

			if (manager == null)
			{
				ModelState.AddModelError(string.Empty, "帳號或密碼錯誤。");
				return View("Login", input);
			}

			// 鎖定檢查
			if (manager.ManagerLockoutEnabled && manager.ManagerLockoutEnd.HasValue && manager.ManagerLockoutEnd.Value > now)
			{
				var mins = (int)Math.Ceiling((manager.ManagerLockoutEnd.Value - now).TotalMinutes);
				ModelState.AddModelError(string.Empty, $"帳號已被鎖定，請於 {mins} 分鐘後再試。");
				return View("Login", input);
			}

			// 這裡以「純文字密碼比對」為例（你之後可改為雜湊：BCrypt/PBKDF2）
			if (!string.Equals(manager.ManagerPassword, pwd))
			{
				// 密碼錯誤 → 增加失敗次數、必要時鎖定
				manager.ManagerAccessFailedCount += 1;
				if (manager.ManagerAccessFailedCount >= MaxFailedAccessCount)
				{
					manager.ManagerLockoutEnabled = true;
					manager.ManagerLockoutEnd = now.Add(LockoutDuration);
				}

				await _db.SaveChangesAsync();
				ModelState.AddModelError(string.Empty, "帳號或密碼錯誤。");
				return View("Login", input);
			}

			// 密碼正確 → 歸零錯誤次數、解除鎖定
			manager.ManagerAccessFailedCount = 0;
			manager.ManagerLockoutEnabled = false;
			manager.ManagerLockoutEnd = null;
			await _db.SaveChangesAsync();

			// 若尚未完成 Email 驗證 → 送出/顯示一次性驗證碼（開發用：TempData 顯示）
			if (!manager.ManagerEmailConfirmed)
			{
				var (code, expireAt) = GenerateOtp();
				HttpContext.Session.SetString(OtpSessionUserIdKey, manager.ManagerId.ToString());
				HttpContext.Session.SetString(OtpSessionCodeKey, code);
				HttpContext.Session.SetString(OtpSessionExpireKey, expireAt.ToUniversalTime().Ticks.ToString());

				// TODO: 寄送 Email 驗證碼到 manager.ManagerEmail
				// 你未接 SMTP 前，先把驗證碼放 TempData（只顯示一次，便於測試）
				TempData["DevOtp"] = code;

				return RedirectToAction(nameof(VerifyEmail));
			}

			// 已驗證 Email → 直接簽入
			await SignInAsync(manager);
			return RedirectToAction(nameof(Success)); // TODO: 換成後台首頁或你要的頁面
		}

		// GET: /Login/VerifyEmail
		[HttpGet]
		[AllowAnonymous]
		public async Task<IActionResult> VerifyEmail()
		{
			var pending = await GetPendingOtpUserAsync();
			if (pending == null)
			{
				// 無待驗證流程就回登入
				return RedirectToAction(nameof(Index));
			}

			var maskedEmail = MaskEmail(pending.ManagerEmail);
			var vm = new VerifyEmailInput { MaskedEmail = maskedEmail };
			return View(vm);
		}

		// POST: /Login/VerifyEmail
		[HttpPost]
		[AllowAnonymous]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> VerifyEmail(VerifyEmailInput input)
		{
			var pending = await GetPendingOtpUserAsync();
			if (pending == null)
			{
				ModelState.AddModelError(string.Empty, "驗證流程已失效，請重新登入。");
				return View(input);
			}

			if (!ModelState.IsValid)
			{
				return View(input);
			}

			var (otpCode, expireAtUtc) = ReadOtpFromSession();
			if (otpCode == null || expireAtUtc == null)
			{
				ModelState.AddModelError(string.Empty, "驗證碼已失效，請重新登入。");
				return View(input);
			}

			if (DateTime.UtcNow > expireAtUtc.Value)
			{
				ModelState.AddModelError(string.Empty, "驗證碼已過期，請重新登入取得新的驗證碼。");
				return View(input);
			}

			if (!string.Equals(otpCode, input.Code?.Trim()))
			{
				ModelState.AddModelError(nameof(input.Code), "驗證碼不正確。");
				return View(input);
			}

			// 通過 → 標記 Email 已驗證 & 簽入
			pending.ManagerEmailConfirmed = true;
			await _db.SaveChangesAsync();

			// 清 Session
			HttpContext.Session.Remove(OtpSessionUserIdKey);
			HttpContext.Session.Remove(OtpSessionCodeKey);
			HttpContext.Session.Remove(OtpSessionExpireKey);

			await SignInAsync(pending);
			return RedirectToAction("Index", "Home"); // TODO: 換成後台首頁或你要的頁面
		}

		// POST: /Login/Logout
		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Logout()
		{
			await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
			return RedirectToAction(nameof(Index));
		}

		// ========= Helper Methods =========
		private async Task SignInAsync(ManagerDatum manager)
		{
			var claims = new List<Claim>
			{
				new Claim(ClaimTypes.NameIdentifier, manager.ManagerId.ToString()),
				new Claim(ClaimTypes.Name, manager.ManagerName ?? manager.ManagerAccount ?? $"Manager#{manager.ManagerId}"),
				new Claim(ClaimTypes.Email, manager.ManagerEmail ?? string.Empty),
				new Claim(ClaimTypes.Role, "Manager"),
				new Claim("IsManager", "true")
			};

			var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
			var principal = new ClaimsPrincipal(identity);

			await HttpContext.SignInAsync(
				CookieAuthenticationDefaults.AuthenticationScheme,
				principal,
				new AuthenticationProperties
				{
					IsPersistent = true,
					ExpiresUtc = DateTimeOffset.UtcNow.AddHours(4) // 可調
				});
		}

		private (string code, DateTime expireAtUtc) GenerateOtp()
		{
			var rnd = new Random();
			var code = rnd.Next(0, 999999).ToString("D6"); // 6 碼
			var expire = DateTime.UtcNow.AddMinutes(10);
			return (code, expire);
		}

		private (string? code, DateTime? expireAtUtc) ReadOtpFromSession()
		{
			var code = HttpContext.Session.GetString(OtpSessionCodeKey);
			var ticks = HttpContext.Session.GetString(OtpSessionExpireKey);
			if (string.IsNullOrEmpty(code) || string.IsNullOrEmpty(ticks))
				return (null, null);

			if (!long.TryParse(ticks, out var t))
				return (null, null);

			return (code, new DateTime(t, DateTimeKind.Utc));
		}

		private async Task<ManagerDatum?> GetPendingOtpUserAsync()
		{
			var userIdStr = HttpContext.Session.GetString(OtpSessionUserIdKey);
			if (!int.TryParse(userIdStr, out var id))
				return null;

			return await _db.ManagerData.FirstOrDefaultAsync(m => m.ManagerId == id);
		}

		private static string MaskEmail(string email)
		{
			if (string.IsNullOrWhiteSpace(email) || !email.Contains("@")) return "（無法顯示）";
			var parts = email.Split('@');
			var name = parts[0];
			var domain = parts[1];
			var maskLen = Math.Max(1, name.Length - 2);
			var head = name.Substring(0, Math.Min(1, name.Length));
			var tail = name.Length > 1 ? name.Substring(name.Length - 1) : "";
			return $"{head}{new string('•', maskLen)}{tail}@{domain}";
		}

		// ========= ViewModels =========
		public class LoginInput
		{
			[Required(ErrorMessage = "請輸入帳號")]
			[Display(Name = "管理者帳號")]
			public string ManagerAccount { get; set; } = "";

			[Required(ErrorMessage = "請輸入密碼")]
			[DataType(DataType.Password)]
			[Display(Name = "密碼")]
			public string ManagerPassword { get; set; } = "";
		}

		public class VerifyEmailInput
		{
			[Display(Name = "驗證碼")]
			[Required(ErrorMessage = "請輸入驗證碼")]
			[StringLength(6, MinimumLength = 6, ErrorMessage = "驗證碼為 6 碼")]
			public string Code { get; set; } = "";

			// 顯示用
			public string? MaskedEmail { get; set; }
		}
		[Authorize]
		[HttpGet]
		public async Task<IActionResult> Success()
		{
			var idStr = User.FindFirstValue(ClaimTypes.NameIdentifier);
			if (!int.TryParse(idStr, out var managerId))
				return RedirectToAction(nameof(Index));

			var manager = await _db.ManagerData
				.Include(m => m.ManagerRoles) // ICollection<ManagerRolePermission>
				.FirstOrDefaultAsync(m => m.ManagerId == managerId);

			var displayName = User.Identity?.Name
							  ?? manager?.ManagerName
							  ?? manager?.ManagerAccount
							  ?? $"Manager#{managerId}";

			var roles = manager?.ManagerRoles?
							.Select(r => r.RoleName)
							.Where(s => !string.IsNullOrWhiteSpace(s))
							.Distinct()
							.ToList()
						?? new List<string>();

			if (roles.Count == 0)
			{
				var claimRole = User.FindFirstValue(ClaimTypes.Role);
				if (!string.IsNullOrWhiteSpace(claimRole))
					roles.Add(claimRole);
			}

			var vm = new LoginSuccessVM
			{
				ManagerId = managerId,
				ManagerName = displayName,
				Positions = roles
			};

			return View("Success", vm);
		}

		public class LoginSuccessVM
		{
			public int ManagerId { get; set; }
			public string ManagerName { get; set; } = "";
			public List<string> Positions { get; set; } = new();
		}
	}
}
