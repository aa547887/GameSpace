﻿// ---- 服務命名空間（一般 using）----
using GameSpace.Areas.social_hub.Services;
using GameSpace.Data;
using GameSpace.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.Cookies;
using System;

// ---- 型別別名（避免方案裡若有重複介面/命名空間不一致，導致 DI 對不到）----
using IMuteFilterAlias = GameSpace.Areas.social_hub.Services.IMuteFilter;
using INotificationServiceAlias = GameSpace.Areas.social_hub.Services.INotificationService;
using MuteFilterAlias = GameSpace.Areas.social_hub.Services.MuteFilter;
using NotificationServiceAlias = GameSpace.Areas.social_hub.Services.NotificationService;
// 權限服務的別名
using IManagerPermissionServiceAlias = GameSpace.Areas.social_hub.Services.IManagerPermissionService;
using ManagerPermissionServiceAlias = GameSpace.Areas.social_hub.Services.ManagerPermissionService;

// ---------------------- 服務註冊 ----------------------
// [保留] 頂層語句：只需要這一個 builder，請先刪除舊的 namespace Program/Main 結構
var builder = WebApplication.CreateBuilder(args);

// [保留] Identity 用的 ApplicationDbContext（你的 DefaultConnection）
var identityConn = builder.Configuration.GetConnectionString("DefaultConnection")
	?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
builder.Services.AddDbContext<ApplicationDbContext>(options => options.UseSqlServer(identityConn));
builder.Services.AddDatabaseDeveloperPageExceptionFilter();

// [保留] GameSpace 主資料庫
var gameSpaceConn = builder.Configuration.GetConnectionString("GameSpace")
	?? throw new InvalidOperationException("Connection string 'GameSpace' not found.");
builder.Services.AddDbContext<GameSpacedatabaseContext>(options => options.UseSqlServer(gameSpaceConn));

// [保留] ASP.NET Core Identity
builder.Services.AddDefaultIdentity<IdentityUser>(options =>
{
	options.SignIn.RequireConfirmedAccount = true;
}).AddEntityFrameworkStores<ApplicationDbContext>();

// [保留] MVC
builder.Services.AddControllersWithViews();

// [保留] social_hub 相關服務註冊
builder.Services.AddMemoryCache();
builder.Services.Configure<MuteFilterOptions>(o =>
{
	o.MaskStyle = MaskStyle.Asterisks;   // 或 FixedLabel
	o.FixedLabel = "【封鎖】";
	o.FuzzyBetweenCjkChars = true;
});
builder.Services.AddScoped<IMuteFilterAlias, MuteFilterAlias>();
builder.Services.AddScoped<INotificationServiceAlias, NotificationServiceAlias>();
builder.Services.AddScoped<IManagerPermissionServiceAlias, ManagerPermissionServiceAlias>();

// [保留] SignalR
builder.Services.AddSignalR();

// [新增] Session（登入流程/OTP 要用）
builder.Services.AddSession(opt =>
{
	opt.IdleTimeout = TimeSpan.FromMinutes(30);
	opt.Cookie.HttpOnly = true;
	opt.Cookie.IsEssential = true;
});

// [新增] Cookie 驗證（給 LoginController 的 Cookies 方案）
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
	.AddCookie(opt =>
	{
		opt.LoginPath = "/Login";
		opt.LogoutPath = "/Login/Logout";
		opt.AccessDeniedPath = "/Login";
		opt.ExpireTimeSpan = TimeSpan.FromHours(4);
		opt.SlidingExpiration = true;
	});

var app = builder.Build();

// [保留] 啟動時預載詞庫（失敗不擋站）
using (var scope = app.Services.CreateScope())
{
	try
	{
		var filter = scope.ServiceProvider.GetRequiredService<IMuteFilterAlias>();
		await filter.RefreshAsync(); // 預熱 Regex 與快取
	}
	catch { /* ignore */ }
}

// ---------------------- 中介層管線 ----------------------
if (app.Environment.IsDevelopment())
{
	app.UseMigrationsEndPoint();
}
else
{
	app.UseExceptionHandler("/Home/Error");
	app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseSession();          // [順序確認] 要在 Auth 前
app.UseAuthentication();
app.UseAuthorization();

// [保留] 先 Areas 再 default
app.MapControllerRoute(
	name: "areas",
	pattern: "{area:exists}/{controller=Home}/{action=Index}/{id?}");

app.MapControllerRoute(
	name: "default",
	pattern: "{controller=Home}/{action=Index}/{id?}");

// [保留] 若使用 Identity UI
app.MapRazorPages();

// [保留] SignalR hub
app.MapHub<GameSpace.Areas.social_hub.Hubs.ChatHub>("/social_hub/chatHub");

await app.RunAsync();
