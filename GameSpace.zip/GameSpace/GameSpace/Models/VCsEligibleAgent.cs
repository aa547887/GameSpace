﻿using System;
using System.Collections.Generic;

namespace GameSpace.Models;

public partial class VCsEligibleAgent
{
    public int ManagerId { get; set; }
}
