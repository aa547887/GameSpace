﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using GameSpace.Models; // GameSpacedatabaseContext, ManagerDatum, ManagerRolePermission
using GameSpace.Areas.MemberManagement.Models; // ManagerWithRoleVM, ManagerRoleAssignVM

namespace GameSpace.Areas.MemberManagement.Controllers
{
	[Area("MemberManagement")]
	public class ManagerWithRolesController : Controller
	{
		private readonly GameSpacedatabaseContext _db;
		public ManagerWithRolesController(GameSpacedatabaseContext db) => _db = db;

		// 只接 ManagerRole 的兩個欄位（不拿名稱）
		private sealed class ManagerRoleRow
		{
			public int ManagerId { get; set; }      // Manager_Id
			public int ManagerRoleId { get; set; }  // ManagerRole_Id
		}

		// ========== Index ==========
		public async Task<IActionResult> Index()
		{
			var managers = await _db.ManagerData
				.AsNoTracking()
				.Select(m => new { m.ManagerId, m.ManagerName })
				.ToListAsync();

			var roleDict = await _db.ManagerRolePermissions
				.AsNoTracking()
				.Select(r => new { r.ManagerRoleId, r.RoleName })
				.ToDictionaryAsync(x => x.ManagerRoleId, x => x.RoleName);

			var links = await _db.Database.SqlQuery<ManagerRoleRow>($@"
                SELECT mr.Manager_Id     AS ManagerId,
                       mr.ManagerRole_Id AS ManagerRoleId
                FROM dbo.ManagerRole AS mr
            ").ToListAsync();

			var result = managers
				.GroupJoin(
					links,
					m => m.ManagerId,
					l => l.ManagerId,
					(m, ls) => ls.Any()
						? ls.Select(x => new ManagerWithRoleVM
						{
							ManagerId = m.ManagerId,
							ManagerName = m.ManagerName,
							ManagerRoleId = x.ManagerRoleId,
							RoleName = roleDict.TryGetValue(x.ManagerRoleId, out var name) ? name : "(未知角色)"
						})
						: new[]
						{
							new ManagerWithRoleVM
							{
								ManagerId = m.ManagerId,
								ManagerName = m.ManagerName,
								ManagerRoleId = 0,
								RoleName = "(無角色)"
							}
						})
				.SelectMany(x => x)
				.OrderBy(x => x.ManagerId)
				.ThenBy(x => x.ManagerRoleId)
				.ToList();

			return View(result);
		}

		// ========== Details ==========
		public async Task<IActionResult> Details(int managerId)
		{
			var manager = await _db.ManagerData
				.AsNoTracking()
				.Where(m => m.ManagerId == managerId)
				.Select(m => new { m.ManagerId, m.ManagerName })
				.FirstOrDefaultAsync();

			if (manager == null) return NotFound();

			var roleDict = await _db.ManagerRolePermissions
				.AsNoTracking()
				.Select(r => new { r.ManagerRoleId, r.RoleName })
				.ToDictionaryAsync(x => x.ManagerRoleId, x => x.RoleName);

			var links = await _db.Database.SqlQuery<ManagerRoleRow>($@"
                SELECT mr.Manager_Id     AS ManagerId,
                       mr.ManagerRole_Id AS ManagerRoleId
                FROM dbo.ManagerRole AS mr
                WHERE mr.Manager_Id = {managerId}
            ").ToListAsync();

			List<ManagerWithRoleVM> model;
			if (links.Count == 0)
			{
				model = new List<ManagerWithRoleVM>
				{
					new ManagerWithRoleVM
					{
						ManagerId = manager.ManagerId,
						ManagerName = manager.ManagerName,
						ManagerRoleId = 0,
						RoleName = "(無角色)"
					}
				};
			}
			else
			{
				model = links
					.Select(x => new ManagerWithRoleVM
					{
						ManagerId = manager.ManagerId,
						ManagerName = manager.ManagerName,
						ManagerRoleId = x.ManagerRoleId,
						RoleName = roleDict.TryGetValue(x.ManagerRoleId, out var name) ? name : "(未知角色)"
					})
					.OrderBy(x => x.ManagerRoleId)
					.ToList();
			}

			return View(model);
		}

		// ========== Edit (GET) ==========
		// 顯示「僅修改 ManagerRoleId」的頁面；其餘欄位唯讀
		public async Task<IActionResult> Edit(int managerId)
		{
			var manager = await _db.ManagerData
				.AsNoTracking()
				.Where(m => m.ManagerId == managerId)
				.Select(m => new { m.ManagerId, m.ManagerName })
				.FirstOrDefaultAsync();
			if (manager == null) return NotFound();

			// 抓目前角色（若多筆取第一筆；沒有則 null/0）
			int? currentRoleId = await _db.Database
	.SqlQuery<int?>($@"
        SELECT TOP(1) mr.ManagerRole_Id AS [Value]
        FROM dbo.ManagerRole AS mr
        WHERE mr.Manager_Id = {managerId}
        ORDER BY mr.ManagerRole_Id")
	.FirstOrDefaultAsync();

			var roleItems = await _db.ManagerRolePermissions
				.AsNoTracking()
				.Select(r => new SelectListItem
				{
					Value = r.ManagerRoleId.ToString(),
					Text = r.RoleName
				})
				.ToListAsync();

			var vm = new ManagerRoleAssignVM
			{
				ManagerId = manager.ManagerId,
				ManagerName = manager.ManagerName,
				SelectedRoleId = currentRoleId ?? 0,
				Roles = roleItems
			};

			return View(vm);
		}

		// ========== Edit (POST) ==========
		// 刪舊插新：SelectedRoleId == 0 表示清除角色
		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Edit(ManagerRoleAssignVM vm)
		{
			if (!ModelState.IsValid)
			{
				vm.Roles = await _db.ManagerRolePermissions
					.AsNoTracking()
					.Select(r => new SelectListItem { Value = r.ManagerRoleId.ToString(), Text = r.RoleName })
					.ToListAsync();
				return View(vm);
			}

			bool managerExists = await _db.ManagerData.AnyAsync(m => m.ManagerId == vm.ManagerId);
			if (!managerExists) return NotFound();

			if (vm.SelectedRoleId != 0)
			{
				bool roleExists = await _db.ManagerRolePermissions
					.AnyAsync(r => r.ManagerRoleId == vm.SelectedRoleId);
				if (!roleExists)
				{
					ModelState.AddModelError(nameof(vm.SelectedRoleId), "選擇的角色不存在。");
					vm.Roles = await _db.ManagerRolePermissions
						.AsNoTracking()
						.Select(r => new SelectListItem { Value = r.ManagerRoleId.ToString(), Text = r.RoleName })
						.ToListAsync();
					return View(vm);
				}
			}

			using var tx = await _db.Database.BeginTransactionAsync();
			try
			{
				// 刪除既有關聯（若允許多角色情境，這步會全部清掉）
				await _db.Database.ExecuteSqlInterpolatedAsync($@"
                    DELETE FROM dbo.ManagerRole
                    WHERE Manager_Id = {vm.ManagerId}");

				// 插入新關聯（若選 0 表示清除角色，就不插）
				if (vm.SelectedRoleId != 0)
				{
					await _db.Database.ExecuteSqlInterpolatedAsync($@"
                        INSERT INTO dbo.ManagerRole (Manager_Id, ManagerRole_Id)
                        VALUES ({vm.ManagerId}, {vm.SelectedRoleId})");
				}

				await tx.CommitAsync();
			}
			catch
			{
				await tx.RollbackAsync();
				throw;
			}

			// 回到該管理者的詳細，立即看到結果
			return RedirectToAction(nameof(Details), new { managerId = vm.ManagerId });
		}
	}
}
