using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GameSpace.Areas.MemberManagement.Views.UserPermissions
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
