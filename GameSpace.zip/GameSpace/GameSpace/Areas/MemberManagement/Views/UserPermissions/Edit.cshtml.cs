using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GameSpace.Areas.MemberManagement.Views.UserPermissions
{
    public class EditModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
