﻿using GameSpace.Areas.social_hub.Models.ViewModels;
using GameSpace.Data;
using GameSpace.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace GameSpace.Areas.social_hub.Controllers
{
	[Area("social_hub")]
	public class MessageCenterController : Controller
	{
		private readonly GameSpacedatabaseContext _context;

		public MessageCenterController(GameSpacedatabaseContext context)
		{
			_context = context;
		}

		// 共用：載入下拉
		private void LoadSelectLists(IEnumerable<int> selectedRecipientIds = null, Notification n = null)
		{
			var users = _context.Users.AsNoTracking().OrderBy(u => u.UserName).ToList();
			ViewBag.Users = new SelectList(users, "UserId", "UserName", selectedRecipientIds);

			ViewBag.Groups = new SelectList(
				_context.Groups.AsNoTracking().OrderBy(g => g.GroupName),
				"GroupId", "GroupName", n?.GroupId);

			ViewBag.Managers = new SelectList(
				_context.ManagerData.AsNoTracking().OrderBy(m => m.ManagerName),
				"ManagerId", "ManagerName", n?.SenderManagerId);

			ViewBag.Actions = new SelectList(
				_context.NotificationActions.AsNoTracking().OrderBy(a => a.ActionName),
				"ActionId", "ActionName", n?.ActionId);

			ViewBag.Sources = new SelectList(
				_context.NotificationSources.AsNoTracking().OrderBy(s => s.SourceName),
				"SourceId", "SourceName", n?.SourceId);
		}

		// 通知列表（依目前登入的使用者）
		public async Task<IActionResult> Index()
		{
			if (!Request.Cookies.TryGetValue("sh_uid", out var uidStr) || !int.TryParse(uidStr, out var userId))
			{
				ViewBag.Hint = "尚未登入，列表為空。請先登入後再查看通知。";
				return View(Enumerable.Empty<GameSpace.Areas.social_hub.Models.ViewModels.NotificationViewModel>());
			}

			var list = await _context.NotificationRecipients
				.Where(nr => nr.UserId == userId)
				.Include(nr => nr.Notification).ThenInclude(n => n.Action)
				.Include(nr => nr.Notification).ThenInclude(n => n.Source)
				.Include(nr => nr.Notification).ThenInclude(n => n.Sender)
				.Include(nr => nr.Notification).ThenInclude(n => n.SenderManager)
				.OrderByDescending(nr => nr.Notification.CreatedAt)
				.Select(nr => new GameSpace.Areas.social_hub.Models.ViewModels.NotificationViewModel
				{
					NotificationId = nr.Notification.NotificationId,
					NotificationTitle = nr.Notification.NotificationTitle,
					NotificationMessage = nr.Notification.NotificationMessage,
					CreatedAt = nr.Notification.CreatedAt,
					IsRead = nr.IsRead,
					SenderName = nr.Notification.Sender!.UserName
								?? nr.Notification.SenderManager!.ManagerName
								?? "系統",
					ActionName = nr.Notification.Action!.ActionName,
					SourceName = nr.Notification.Source!.SourceName
				})
				.ToListAsync();

			return View(list);
		}

		// 標記已讀
		[HttpPost]
		public async Task<IActionResult> MarkAsRead(int recipientId)
		{
			var recipient = await _context.NotificationRecipients.FindAsync(recipientId);
			if (recipient == null) return NotFound();

			if (!recipient.IsRead)
			{
				recipient.IsRead = true;
				recipient.ReadAt = DateTime.Now;
				await _context.SaveChangesAsync();
			}
			return Ok();
		}

		// 建立表單
		[HttpGet]
		public IActionResult Create()
		{
			LoadSelectLists();
			return View();
		}

		// 建立提交：支援群發（recipientMode + recipientIds[]）
		// recipientMode: specific | all_users | all_managers | both
		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Create(
			Notification notification,
			string recipientMode,
			int[] recipientIds // 僅在 specific 模式下使用（多選）
		)
		{
			// 導航屬性不是表單來源，移除此類驗證（你也已用 Metadata 標記 ValidateNever）
			ModelState.Remove(nameof(notification.Action));
			ModelState.Remove(nameof(notification.Source));
			ModelState.Remove(nameof(notification.Sender));
			ModelState.Remove(nameof(notification.SenderManager));
			ModelState.Remove(nameof(notification.Group));
			ModelState.Remove(nameof(notification.NotificationRecipients));

			// 長度限制（依 Excel 規格）
			if (!string.IsNullOrWhiteSpace(notification.NotificationTitle) && notification.NotificationTitle.Length > 20)
				ModelState.AddModelError(nameof(notification.NotificationTitle), "標題最多 20 字。");
			if (!string.IsNullOrWhiteSpace(notification.NotificationMessage) && notification.NotificationMessage.Length > 255)
				ModelState.AddModelError(nameof(notification.NotificationMessage), "內容最多 255 字。");

			// 必填
			if (string.IsNullOrWhiteSpace(notification.NotificationTitle))
				ModelState.AddModelError(nameof(notification.NotificationTitle), "請輸入通知標題。");
			if (string.IsNullOrWhiteSpace(notification.NotificationMessage))
				ModelState.AddModelError(nameof(notification.NotificationMessage), "請輸入通知內容。");

			// 外鍵存在性
			if (notification.SourceId <= 0)
				ModelState.AddModelError(nameof(notification.SourceId), "請選擇來源。");
			else if (!await _context.NotificationSources.AnyAsync(s => s.SourceId == notification.SourceId))
				ModelState.AddModelError(nameof(notification.SourceId), $"來源不存在 (SourceId={notification.SourceId})。");

			if (notification.ActionId <= 0)
				ModelState.AddModelError(nameof(notification.ActionId), "請選擇動作。");
			else if (!await _context.NotificationActions.AnyAsync(a => a.ActionId == notification.ActionId))
				ModelState.AddModelError(nameof(notification.ActionId), $"動作不存在 (ActionId={notification.ActionId})。");

			// 解析收件人
			var targets = new HashSet<int>(); // user_ids
			int skippedManagers = 0;

			recipientMode = (recipientMode ?? "specific").Trim().ToLowerInvariant();

			if (recipientMode == "all_users" || recipientMode == "both")
			{
				var allUsers = await _context.Users.AsNoTracking().Select(u => u.UserId).ToListAsync();
				foreach (var uid in allUsers) targets.Add(uid);
			}

			if (recipientMode == "all_managers" || recipientMode == "both")
			{
				// 以帳號對帳：ManagerAccount ↔ UserAccount
				var managerJoin = await (
					from m in _context.ManagerData.AsNoTracking()
					join u in _context.Users.AsNoTracking()
						on m.ManagerAccount equals u.UserAccount
					select u.UserId
				).Distinct().ToListAsync();

				var managerCount = await _context.ManagerData.CountAsync();
				skippedManagers = managerCount - managerJoin.Count; // 粗估：沒有對到的管理員數

				foreach (var uid in managerJoin) targets.Add(uid);
			}

			if (recipientMode == "specific")
			{
				if (recipientIds != null && recipientIds.Length > 0)
				{
					// 僅保留真實存在的使用者
					var wanted = recipientIds.Where(x => x > 0).Distinct().ToArray();
					if (wanted.Length > 0)
					{
						var exists = await _context.Users
							.Where(u => wanted.Contains(u.UserId))
							.Select(u => u.UserId)
							.ToListAsync();
						foreach (var uid in exists) targets.Add(uid);
					}
				}
			}

			if (targets.Count == 0)
				ModelState.AddModelError("recipientIds", "至少需指定一位收件人（請選擇模式或多選使用者）。");

			if (!ModelState.IsValid)
			{
				ViewBag.AllErrors = string.Join("；", ModelState
					.Where(kv => kv.Value.Errors.Count > 0)
					.SelectMany(kv => kv.Value.Errors.Select(e => $"[{kv.Key}] {e.ErrorMessage}")));

				// 把已選使用者回填到下拉（specific 模式）
				LoadSelectLists(recipientMode == "specific" ? targets : null, notification);
				ViewBag.RecipientMode = recipientMode;
				return View(notification);
			}

			// 寫入
			notification.CreatedAt = DateTime.Now;

			foreach (var uid in targets)
			{
				notification.NotificationRecipients.Add(new NotificationRecipient
				{
					UserId = uid,
					IsRead = false
				});
			}

			try
			{
				_context.Notifications.Add(notification);
				await _context.SaveChangesAsync();

				var summary = $"✅ 已建立 1 則通知（ID #{notification.NotificationId}），指派 {targets.Count} 位收件人。";
				if ((recipientMode == "all_managers" || recipientMode == "both") && skippedManagers > 0)
				{
					summary += $"（注意：有 {skippedManagers} 位管理員找不到對應使用者帳號，已略過）";
				}

				TempData["Message"] = summary;
				return RedirectToAction(nameof(Index));
			}
			catch (DbUpdateException ex)
			{
				var baseMsg = ex.GetBaseException()?.Message ?? ex.Message;
				ModelState.AddModelError(string.Empty, "儲存失敗（DbUpdateException）：" + baseMsg);
			}
			catch (Exception ex)
			{
				ModelState.AddModelError(string.Empty, "儲存失敗（Exception）：" + ex.Message);
			}

			LoadSelectLists(recipientMode == "specific" ? targets : null, notification);
			ViewBag.RecipientMode = recipientMode;
			return View(notification);
		}

		// 你既有的測試端點（保留）
		[HttpGet]
		public async Task<IActionResult> TestNotification()
		{
			int userId = 10000012;
			var user = await _context.Users.FindAsync(userId);
			if (user == null) return Content($"UserId {userId} 不存在");

			var notification = new Notification
			{
				SourceId = 1,
				ActionId = 1,
				SenderId = null,
				SenderManagerId = 30000012,
				NotificationTitle = "測試通知",
				NotificationMessage = "這是一則測試通知",
				CreatedAt = DateTime.Now
			};
			notification.NotificationRecipients.Add(new NotificationRecipient
			{
				UserId = userId,
				IsRead = false
			});

			_context.Notifications.Add(notification);
			await _context.SaveChangesAsync();
			return Content("測試通知已新增完成！");
		}
	}
}
