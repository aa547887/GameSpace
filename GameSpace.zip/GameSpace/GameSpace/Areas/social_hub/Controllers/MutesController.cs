﻿using GameSpace.Areas.social_hub.Services;
using GameSpace.Filters;
using GameSpace.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace GameSpace.Areas.social_hub.Controllers
{
	[Area("social_hub")]
	public class MutesController : Controller
	{
		private readonly GameSpacedatabaseContext _context;
		private readonly IMuteFilter _filter;

		public MutesController(GameSpacedatabaseContext context, IMuteFilter filter)
		{
			_context = context;
			_filter = filter;
		}

		// 檢視可開放；若要全鎖，補 [AdminOnly]
		public async Task<IActionResult> Index()
		{
			ViewBag.IsAdmin = await IsCurrentUserAdminAsync();
			var list = await _context.Mutes
				.AsNoTracking()
				.OrderByDescending(m => m.CreatedAt)
				.ToListAsync();

			return View(list);
		}

		// 檢視可開放
		public async Task<IActionResult> Details(int? id)
		{
			if (id is null) return NotFound();
			ViewBag.IsAdmin = await IsCurrentUserAdminAsync();

			var mute = await _context.Mutes
				.AsNoTracking()
				.FirstOrDefaultAsync(m => m.MuteId == id);

			if (mute is null) return NotFound();
			return View(mute);
		}

		// ===== 只有管理員 =====

		[AdminOnly]
		public IActionResult Create() => View();

		[AdminOnly]
		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Create([Bind("MuteName,IsActive")] Mute input)
		{
			if (!ModelState.IsValid) return View(input);

			var uid = CurrentUserId();
			var entity = new Mute
			{
				MuteName = input.MuteName?.Trim(),
				IsActive = input.IsActive,
				CreatedAt = DateTime.UtcNow,
				ManagerId = uid // ← 寫入建立者 id
			};

			_context.Mutes.Add(entity);
			await _context.SaveChangesAsync();

			TempData["Toast"] = "✅ 已新增穢語。";
			return RedirectToAction(nameof(Index));
		}

		[AdminOnly]
		public async Task<IActionResult> Edit(int? id)
		{
			if (id is null) return NotFound();
			var mute = await _context.Mutes.FindAsync(id);
			if (mute is null) return NotFound();
			return View(mute);
		}

		[AdminOnly]
		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Edit(int id, [Bind("MuteId,MuteName,IsActive")] Mute input)
		{
			if (id != input.MuteId) return NotFound();
			if (!ModelState.IsValid) return View(input);

			var entity = await _context.Mutes.FindAsync(id);
			if (entity is null) return NotFound();

			entity.MuteName = input.MuteName?.Trim();
			entity.IsActive = input.IsActive;

			await _context.SaveChangesAsync();

			TempData["Toast"] = "✅ 已更新穢語。";
			return RedirectToAction(nameof(Index));
		}

		[AdminOnly]
		public async Task<IActionResult> Delete(int? id)
		{
			if (id is null) return NotFound();

			var mute = await _context.Mutes
				.AsNoTracking()
				.FirstOrDefaultAsync(m => m.MuteId == id);

			if (mute is null) return NotFound();
			return View(mute);
		}

		[AdminOnly]
		[HttpPost, ActionName("Delete")]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> DeleteConfirmed(int id)
		{
			var mute = await _context.Mutes.FindAsync(id);
			if (mute != null)
			{
				_context.Mutes.Remove(mute);
				await _context.SaveChangesAsync();
			}

			TempData["Toast"] = "🗑️ 已刪除。";
			return RedirectToAction(nameof(Index));
		}

		[AdminOnly]
		[HttpPost]
		[ValidateAntiForgeryToken]
		public IActionResult ReloadCache()
		{
			_filter.Refresh();
			TempData["Toast"] = "🔄 遮蔽詞庫已重載。";
			return RedirectToAction(nameof(Index));
		}

		[AdminOnly]
		[HttpGet]
		public IActionResult Preview() => View();

		[AdminOnly]
		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Preview(string text)
		{
			text ??= string.Empty;
			var result = await _filter.FilterAsync(text);
			ViewBag.Input = text;
			ViewBag.Output = result;
			return View();
		}

		// Helpers －－－－－－－－－－－－－－－－－－－－－－－

		private int? CurrentUserId()
		{
			if (Request.Cookies.TryGetValue("sh_uid", out var s) &&
				int.TryParse(s, out var uid) && uid > 0)
				return uid;

			return null;
		}

		private async Task<bool> IsCurrentUserAdminAsync()
		{
			var uid = CurrentUserId();
			if (uid is null || uid <= 0) return false;

			// 與 AdminOnlyAttribute 的檢查保持一致
			return await _context.ManagerData
				.AsNoTracking()
				.Where(m => m.ManagerId == uid)
				.SelectMany(m => m.ManagerRoles) // ManagerRolePermission
				.AnyAsync(rp => rp.ManagerRoleId == 1 || rp.ManagerRoleId == 2 || rp.ManagerRoleId == 8);
		}
	}
}
