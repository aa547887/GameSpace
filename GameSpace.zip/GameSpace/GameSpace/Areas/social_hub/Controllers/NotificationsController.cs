﻿// Areas/social_hub/Controllers/NotificationsController.cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GameSpace.Areas.social_hub.Filters;       // ★ 單一權限屬性 RequireManagerPermissions
using GameSpace.Areas.social_hub.Services;
using GameSpace.Models;
using GameSpace.Infrastructure.Login;           // ★ ILoginIdentity
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GameSpace.Areas.social_hub.Controllers
{
	[Area("social_hub")]
	public class NotificationsController : Controller
	{
		private readonly GameSpacedatabaseContext _db;
		private readonly INotificationService _notificationService;
		private readonly ILoginIdentity _login; // ★ 統一身分來源（外部 AdminCookie/Claims）

		public NotificationsController(
			GameSpacedatabaseContext db,
			INotificationService notificationService,
			ILoginIdentity login)
		{
			_db = db;
			_notificationService = notificationService;
			_login = login;
		}

		// 依目前登入者判斷是否具「管理員總管」權限（AdministratorPrivilegesManagement == true）
		// 若你仍要沿用舊的 {1,2,8} 角色白名單，可在查詢中加上 rp.ManagerRoleId IN (1,2,8)
		private async Task<bool> IsCurrentAdminAsync()
		{
			var me = await _login.GetAsync();
			if (!me.IsAuthenticated || me.ManagerId is null) return false;

			var mid = me.ManagerId.Value;
			return await _db.ManagerData
				.AsNoTracking()
				.Where(m => m.ManagerId == mid)
				.SelectMany(m => m.ManagerRoles)
				.AnyAsync(rp =>
					(rp.AdministratorPrivilegesManagement ?? false)
				// || rp.ManagerRoleId == 1 || rp.ManagerRoleId == 2 || rp.ManagerRoleId == 8   // ← 如需舊白名單，解除註解
				);
		}

		// 取得「發送者身分」：依外部登入把 senderUserId / senderManagerId 映射好
		private async Task<(int? senderUserId, int? senderManagerId)> GetSenderAsync()
		{
			var me = await _login.GetAsync();
			if (!me.IsAuthenticated) return (null, null);

			// 外部登入是 manager 則填 managerId；若是 user 則填 userId
			if (string.Equals(me.Kind, "manager", StringComparison.OrdinalIgnoreCase) && me.ManagerId is int mid)
				return (null, mid);

			if (string.Equals(me.Kind, "user", StringComparison.OrdinalIgnoreCase) && me.UserId is int uid)
				return (uid, null);

			return (null, null);
		}

		// ============ 清單 ============
		// 任何登入者都可看清單；前端以 ViewBag.IsAdmin 控制是否顯示「建立/群發」按鈕
		[HttpGet]
		public async Task<IActionResult> Index()
		{
			ViewBag.IsAdmin = await IsCurrentAdminAsync();

			var list = await _db.Notifications
				.AsNoTracking()
				.OrderByDescending(n => n.CreatedAt)
				.ToListAsync();

			return View(list);
		}

		// ============ 建立 ============
		// 只有 Admin 可進入
		[HttpGet]
		[RequireManagerPermissions(Admin = true)]
		public IActionResult Create() => View();

		/// <summary>
		/// 建立單一通知並指定多位收件人（收件人寫入 NotificationRecipients）
		/// </summary>
		[HttpPost]
		[ValidateAntiForgeryToken]
		[RequireManagerPermissions(Admin = true)]
		public async Task<IActionResult> Create(
			[Bind("NotificationTitle,NotificationMessage,SourceId,ActionId")] Notification input,
			List<int> recipientIds)
		{
			if (!ModelState.IsValid) return View(input);

			var (senderUserId, senderManagerId) = await GetSenderAsync();

			// 用服務處理：驗證 sender、過濾無效收件人、去重等
			var added = await _notificationService.CreateAsync(
				input,
				recipientIds ?? Enumerable.Empty<int>(),
				senderUserId,
				senderManagerId
			);

			TempData["Toast"] = $"✅ 已建立通知 #{input.NotificationId}，成功寄給 {added} 位收件人。";
			return RedirectToAction(nameof(Index));
		}

		/// <summary>
		/// 範例：依管理員角色群發。
		/// 注意：若 ManagerId 不是 Users.UserId，會在服務層被過濾掉以避免 FK 錯誤。
		/// 若你的實際關聯有「Manager 對應 UserId」，建議先在這裡映射後再傳入。
		/// </summary>
		[HttpPost]
		[ValidateAntiForgeryToken]
		[RequireManagerPermissions(Admin = true)]
		public async Task<IActionResult> BroadcastToRole(
			int roleId,
			[Bind("NotificationTitle,NotificationMessage,SourceId,ActionId")] Notification template)
		{
			var (senderUserId, senderManagerId) = await GetSenderAsync();

			// 目前先取所有有該角色的 ManagerId 當「擬收件清單」
			// 若這些 ID 不在 Users 表，就會在服務層被過濾掉
			var receivers = await _db.ManagerData
				.AsNoTracking()
				.Where(m => m.ManagerRoles.Any(rp => rp.ManagerRoleId == roleId))
				.Select(m => m.ManagerId)
				.ToListAsync();

			var added = await _notificationService.CreateAsync(
				template,
				receivers,
				senderUserId,
				senderManagerId
			);

			TempData["Toast"] = $"📣 群發完成（有效收件人：{added} 位）。";
			return RedirectToAction(nameof(Index));
		}
	}
}
