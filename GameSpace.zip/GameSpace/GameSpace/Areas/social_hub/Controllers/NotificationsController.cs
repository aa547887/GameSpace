﻿using GameSpace.Filters;
using GameSpace.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace GameSpace.Areas.social_hub.Controllers
{
	[Area("social_hub")]
	public class NotificationsController : Controller
	{
		private readonly GameSpacedatabaseContext _context;

		public NotificationsController(GameSpacedatabaseContext context)
		{
			_context = context;
		}

		public async Task<IActionResult> Index()
		{
			ViewBag.IsAdmin = await IsCurrentUserAdminAsync();
			var list = await _context.Notifications
				.AsNoTracking()
				.OrderByDescending(n => n.CreatedAt)
				.ToListAsync();

			return View(list);
		}

		[AdminOnly]
		public IActionResult Create() => View();

		[AdminOnly]
		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Create([Bind("NotificationTitle,NotificationMessage,SourceId,ActionId,TargetUserId")] Notification input)
		{
			if (!ModelState.IsValid) return View(input);

			var entity = new Notification
			{
				NotificationTitle = input.NotificationTitle,
				NotificationMessage = input.NotificationMessage,
				SourceId = input.SourceId,
				ActionId = input.ActionId,
				SenderId = CurrentUserId(), // ← 寫入發送者 id
				TargetUserId = input.TargetUserId,
				CreatedAt = DateTime.UtcNow,
				IsRead = false
			};

			_context.Notifications.Add(entity);
			await _context.SaveChangesAsync();

			TempData["Toast"] = "✅ 通知已發送。";
			return RedirectToAction(nameof(Index));
		}

		// 群發範例（可選）：條件/角色/多選時逐筆建立
		[AdminOnly]
		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> BroadcastToRole(int roleId, [Bind("NotificationTitle,NotificationMessage,SourceId,ActionId")] Notification template)
		{
			var sender = CurrentUserId();

			var receivers = await _context.ManagerData
				.AsNoTracking()
				.Where(m => m.ManagerRoles.Any(rp => rp.ManagerRoleId == roleId))
				.Select(m => m.ManagerId)
				.ToListAsync();

			foreach (var rid in receivers)
			{
				_context.Notifications.Add(new Notification
				{
					NotificationTitle = template.NotificationTitle,
					NotificationMessage = template.NotificationMessage,
					SourceId = template.SourceId,
					ActionId = template.ActionId,
					SenderId = sender,               // ← 發送者
					TargetUserId = rid,              // ← 收件者
					CreatedAt = DateTime.UtcNow,
					IsRead = false
				});
			}

			await _context.SaveChangesAsync();
			TempData["Toast"] = $"📣 已群發 {receivers.Count} 筆。";
			return RedirectToAction(nameof(Index));
		}

		// Helpers
		private int? CurrentUserId()
		{
			if (Request.Cookies.TryGetValue("sh_uid", out var s) &&
				int.TryParse(s, out var uid) && uid > 0)
				return uid;
			return null;
		}

		private async Task<bool> IsCurrentUserAdminAsync()
		{
			var uid = CurrentUserId();
			if (uid is null || uid <= 0) return false;

			return await _context.ManagerData
				.AsNoTracking()
				.Where(m => m.ManagerId == uid)
				.SelectMany(m => m.ManagerRoles)
				.AnyAsync(rp => rp.ManagerRoleId == 1 || rp.ManagerRoleId == 2 || rp.ManagerRoleId == 8);
		}
	}
}
