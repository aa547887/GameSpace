using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GameSpace.Areas.social_hub.Views.MessageCenter
{
    public class DetailModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
