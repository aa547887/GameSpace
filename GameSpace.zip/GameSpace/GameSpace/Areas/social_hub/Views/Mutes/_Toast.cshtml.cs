using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GameSpace.Areas.social_hub.Views.Mutes
{
    public class _ToastModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
