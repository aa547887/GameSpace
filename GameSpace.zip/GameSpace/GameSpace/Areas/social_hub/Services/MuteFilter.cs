﻿using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using GameSpace.Models;

namespace GameSpace.Areas.social_hub.Services
{
	public class MuteFilter : IMuteFilter
	{
		private readonly GameSpacedatabaseContext _db;
		private readonly IMemoryCache _cache;

		private const string CacheKey = "social_hub:mutes:v2";
		private static readonly TimeSpan Ttl = TimeSpan.FromMinutes(5);
		private const string DefaultReplacement = "【封鎖詞句】";

		public MuteFilter(GameSpacedatabaseContext db, IMemoryCache cache)
		{
			_db = db;
			_cache = cache;
		}

		public void Refresh() => _cache.Remove(CacheKey);

		public async Task<string> FilterAsync(string input)
		{
			if (string.IsNullOrEmpty(input)) return input ?? string.Empty;

			var cfg = await GetOrBuildAsync();
			if (cfg.Pattern == null) return input;

			// 如需更強防繞過可在此加 Normalize；先保留原文以免顯示亂碼
			return cfg.Pattern.Replace(input, _ => DefaultReplacement);
		}

		private async Task<MuteConfig> GetOrBuildAsync()
		{
			if (_cache.TryGetValue(CacheKey, out MuteConfig cached) && cached != null)
				return cached;

			// 1) 讀取 Mutes（僅啟用）
			var words1 = await _db.Mutes
				.AsNoTracking()
				.Where(m => m.IsActive && m.MuteName != null && m.MuteName != "")
				.Select(m => m.MuteName!)
				.ToListAsync();

			// 2) 讀取 BannedWords（全取）
			var words2 = await _db.BannedWords
				.AsNoTracking()
				.Where(b => b.Word != null && b.Word != "")
				.Select(b => b.Word!)
				.ToListAsync();

			var all = words1
				.Concat(words2)
				.Select(w => w.Trim())
				.Where(w => w.Length > 0)
				.Distinct(StringComparer.OrdinalIgnoreCase)
				// 先長詞後短詞，避免「王八蛋」被「王八」先吃掉
				.OrderByDescending(w => w.Length)
				.ToList();

			if (all.Count == 0)
			{
				var empty = new MuteConfig();
				_cache.Set(CacheKey, empty, Ttl);
				return empty;
			}

			// 安全地組 Regex（全部 Escape）
			var escaped = all.Select(Regex.Escape);
			var pattern = string.Join("|", escaped);

			// 如要更抗繞過：把每個中文字改成「允許夾雜非字元」的樣式，可再進階處理
			var regex = new Regex(pattern,
				RegexOptions.Compiled |
				RegexOptions.CultureInvariant |
				RegexOptions.IgnoreCase |
				RegexOptions.Singleline);

			var cfg = new MuteConfig { Pattern = regex };
			_cache.Set(CacheKey, cfg, Ttl);
			return cfg;
		}

		private sealed class MuteConfig
		{
			public Regex? Pattern { get; set; }
		}
	}
}
