﻿using System.Threading.Tasks;

namespace GameSpace.Areas.social_hub.Services
{
	public interface IMuteFilter
	{
		/// <summary>將輸入句子中的敏感詞以替代字串遮蔽。</summary>
		Task<string> FilterAsync(string input);

		/// <summary>清除快取，強制重新載入資料庫字詞。</summary>
		void Refresh();
	}
}
