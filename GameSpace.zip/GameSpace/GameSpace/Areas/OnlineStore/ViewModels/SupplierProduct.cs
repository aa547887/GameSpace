﻿namespace GameSpace.Areas.OnlineStore.ViewModels
{
    public class SupplierProduct
    {
    }
}
