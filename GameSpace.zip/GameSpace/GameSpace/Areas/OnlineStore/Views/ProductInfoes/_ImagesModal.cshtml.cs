using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GameSpace.Areas.OnlineStore.Views.ProductInfoes
{
    public class _ImagesModalModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
